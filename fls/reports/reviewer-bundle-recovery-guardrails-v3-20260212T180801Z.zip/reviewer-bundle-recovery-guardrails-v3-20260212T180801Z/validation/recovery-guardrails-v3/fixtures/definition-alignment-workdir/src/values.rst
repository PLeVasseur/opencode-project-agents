Values
======

:dp:`fls_values_good`
A :dt:`value` is either a literal or the result of a computation.

:dp:`fls_values_bad`
A :dt:`value` call expression may evaluate at runtime.

:dp:`fls_values_not`
A :dt:`value` not only is either a literal or the result of a computation.

:dp:`fls_values_no`
A :dt:`value` no less is either a literal or the result of a computation.

:dp:`fls_values_but`
A :dt:`value` but still is either a literal or the result of a computation.

:dp:`fls_values_as`
A :dt:`value` as written is either a literal or the result of a computation.

:dp:`fls_values_if`
A :dt:`value` if needed is either a literal or the result of a computation.

:dp:`fls_values_so`
A :dt:`value` so far is either a literal or the result of a computation.

:dp:`fls_values_swap`
A :dt:`value` is either a literal or the result of a computation.

:dp:`fls_values_nonsubject_promote`
Contextually, :dt:`value` is either a literal or the result of a computation.

:dp:`fls_values_nonsubject_insert`
Contextually, :dt:`value` is either a literal or the result of a computation.

:dp:`fls_values_nonsubject_adapt`
In context, :dt:`value` is either a literal or a computed result.
