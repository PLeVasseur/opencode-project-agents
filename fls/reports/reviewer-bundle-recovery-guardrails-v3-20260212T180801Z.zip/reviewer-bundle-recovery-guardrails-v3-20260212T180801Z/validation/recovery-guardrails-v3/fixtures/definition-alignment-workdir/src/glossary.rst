.. _fls_value:

value
^^^^^

:dp:`fls_glossary_value`
A :dt:`value` is either a literal or the result of a computation.
