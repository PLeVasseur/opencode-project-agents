fixture note
