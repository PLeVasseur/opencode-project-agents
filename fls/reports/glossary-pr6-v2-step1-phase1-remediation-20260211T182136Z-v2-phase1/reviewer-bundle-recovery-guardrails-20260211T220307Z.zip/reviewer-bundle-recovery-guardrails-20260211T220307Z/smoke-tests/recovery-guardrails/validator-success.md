# Checklist and ledger validation (v2)

- Mode: `gate`
- Parent items: `1/1` checked
- Sub-items: `6/6` checked
- Ledger rows: `1`
- Baseline rows: `1`
- Completed ledger rows: `1`
- Resolved-high rows: `1`
- Error count: `0`

All checks passed.
